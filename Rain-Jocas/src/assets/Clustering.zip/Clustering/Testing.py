from sklearn import metrics
from kMeans import *
from DBSCAN import *
from sklearn.datasets import make_blobs 
import matplotlib.pyplot as plt 
import time

"""
Measures the similarity of the true and predicted classes, ignoring permutations (swapping
class names does not change scores)
Returns a value between 0 and 1, The closer to 1, the better the score (the better the predictions)
"""
def randIndex(true, pred):
    score = metrics.rand_score(true, pred)
    return score

"""
Measures the agreement of the true and predicted classes, ignoring permutations (swapping
class names does not change scores)
Returns a value between 0 and 1. A value of one mean class assignments are in total agreement.
A value of zero means class assignments are completely independent.
"""
def mutualInformation(true, pred):
    score = metrics.adjusted_mutual_info_score(true, pred)
    return score

"""
Tests the homogeneity of the predicted classes. A homogenous result means each cluster only
contains points from a single class, based on the true assignments
Returns a value between 0 and 1, where 1 is fully homogenous and 0 is not homogenous at all
"""
def homogeneity(true, pred):
    score = metrics.homogeneity_score(true, pred)
    return score

"""
Tests the completeness of the predicted classes. A complete result means all points of a
given class are assigned to the same cluster, based on the true assignments
Returns a value between 0 and 1, where 1 is fully complete and 0 is not complete at all
"""
def completeness(true, pred):
    score = metrics.completeness_score(true, pred)
    return score


"""
Returns the metrics for a single make_blobs scatterplot
calculates kMeans and DBSCAN metrics based on a combination on k, epsilon, and minSamples input
returns a dataframe with the randIndex, mutualInformation, homogeneity, and completeness metrics
for each algorithm
"""
def getMetrics(X, true, k, epsilon, minSamples):
    #kmeans test
    startTime = time.time()
    df, pred = kMeans(X, k)
    endTime = time.time()
    runTime = endTime - startTime

    #storing kmeans metrics
    kMeansMetrics = [randIndex(true, pred),
                    mutualInformation(true, pred),
                    homogeneity(true, pred),
                    completeness(true, pred),
                    runTime]
    
    #dbscan test
    startTime = time.time()
    #epsilon = 6/minSamples
    df, pred = dbscan(X, epsilon, minSamples)
    endTime = time.time()
    runTime = endTime - startTime

    #storing dbscan metrics
    dbscanMetrics = [randIndex(true, pred),
                    mutualInformation(true, pred),
                    homogeneity(true, pred),
                    completeness(true, pred),
                    runTime]
    
    #Making dataframe from results
    results = {'DBSCAN': dbscanMetrics, 'kMeans': kMeansMetrics}
    results = {'Random-Index ': [kMeansMetrics[0], dbscanMetrics[0]],
                'Mutual Information ': [kMeansMetrics[1], dbscanMetrics[1]],
                'Homogeneity ': [kMeansMetrics[2], dbscanMetrics[2]],
                'Completeness ': [kMeansMetrics[3], dbscanMetrics[3]],
                'Run Time (sec) ': [kMeansMetrics[4], dbscanMetrics[4]]}
    results = pd.DataFrame(results)
    results.rename(index={0: 'kMeans'}, inplace=True)
    results.rename(index={1: 'DBSCAN'}, inplace=True)

    return results

"""
K should always be set to a number <= the number of samples. Ideally, it should be set to
the same number as the number of classes, but there is leeway. The closer to the true  number of
classes k is, the closer Random-Index and Mutual Information should be to 1
minSamples should always be set to at least the dimensionality of the data (two in this). It should not
ever be greater than epsilon

A good Epsilon is dependent on a case-by-case analysis of the sample. It should not be > than the
dimensions (width, length, etc.)
"""
def runTests():
    #tests on 10 points
    X, true = make_blobs(n_samples=25, centers=5, n_features=2, random_state=10)
    print("\nSIZE: 10, k = 1, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 1, 1, 1))
    print("\nSIZE: 10, k = 3, epsilon = 3, minSamples = 3\n\n", getMetrics(X, true, 3, 3, 3))
    print("\nSIZE: 10, k = 3, epsilon = 3, minSamples = 5\n\n", getMetrics(X, true, 5, 3, 5))
    print("\nSIZE: 10, k = 5, epsilon = 5, minSamples = 5\n\n", getMetrics(X, true, 5, 5, 5)) 
    print("\nSIZE: 10, k = 10, epsilon = 10, minSamples = 5\n\n", getMetrics(X, true, 10, 10, 5))
    print("\nSIZE: 10, k = 10, epsilon = 10, minSamples = 10\n\n", getMetrics(X, true, 10, 10, 10))

    #tests on 100 points
    X, true = make_blobs(n_samples=25, centers=5, n_features=2, random_state=100)
    print("\nSIZE: 100, k = 1, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 1, 1, 1))
    print("\nSIZE: 100, k = 3, epsilon = 3, minSamples = 3\n\n", getMetrics(X, true, 3, 3, 3))
    print("\nSIZE: 100, k = 3, epsilon = 3, minSamples = 3\n\n", getMetrics(X, true, 3, 5, 5))
    print("\nSIZE: 100, k = 5, epsilon = 5, minSamples = 5\n\n", getMetrics(X, true, 5, 5, 5)) 
    print("\nSIZE: 100, k = 10, epsilon = 10, minSamples = 5\n\n", getMetrics(X, true, 10, 10, 5))
    print("\nSIZE: 100, k = 10, epsilon = 10, minSamples = 10\n\n", getMetrics(X, true, 10, 10, 10))
    print("\nSIZE: 100, k = 50, epsilon = 50, minSamples = 10\n\n", getMetrics(X, true, 50, 50, 10))
    print("\nSIZE: 100, k = 50, epsilon = 50, minSamples = 25\n\n", getMetrics(X, true, 50, 50, 25))
    print("\nSIZE: 100, k = 50, epsilon = 100, minSamples = 25\n\n", getMetrics(X, true, 50, 100, 25))
    print("\nSIZE: 100, k = 100, epsilon = 100, minSamples = 25\n\n", getMetrics(X, true, 100, 100, 25))
    # print("\nSIZE: 100, k = 50, epsilon = 50, minSamples = 25\n\n", getMetrics(X, true, 50, 50, 26))

    #tests on 1000 points
    X, true = make_blobs(n_samples=25, centers=5, n_features=2, random_state=1000)
    print("\nSIZE: 1000, k = 1, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 1, 1, 1))
    print("\nSIZE: 1000, k = 1, epsilon = 100, minSamples = 1\n\n", getMetrics(X, true, 1, 100, 1))
    print("\nSIZE: 1000, k = 1, epsilon = 10, minSamples = 10\n\n", getMetrics(X, true, 1, 10, 10))
    print("\nSIZE: 1000, k = 1, epsilon = 100, minSamples = 25\n\n", getMetrics(X, true, 1, 100, 25))
    print("\nSIZE: 1000, k = 5, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 5, 1, 1))
    print("\nSIZE: 1000, k = 10, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 10, 1, 1))
    print("\nSIZE: 1000, k = 25, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 25, 1, 1))
    print("\nSIZE: 1000, k = 50, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 50, 1, 1))
    print("\nSIZE: 1000, k = 100, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 100, 1, 1))
    print("\nSIZE: 1000, k = 1000, epsilon = 1, minSamples = 1\n\n", getMetrics(X, true, 1000, 1, 1))
    #print("\nSIZE: 1000, k = 1, epsilon = 100, minSamples = 26\n\n", getMetrics(X, true, 1, 100, 26))


runTests()