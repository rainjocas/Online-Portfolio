"""
Author: Rain Jocas

Sources: https://dev.to/rajaniraiyn/dbscan-clustering-algorithm-demystified-1d5o
https://www.datacamp.com/tutorial/dbscan-clustering-algorithm

"""

import pandas as pd
import numpy as np
import sklearn
from sklearn.datasets import fetch_california_housing
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_blobs

"""
Find Euclidean distance between two points
"""
def Euclidean(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    xSquared = ((x1 - x2)**2)
    ySquared = ((y1 - y2)**2)
    return np.sqrt(xSquared + ySquared)

"""
Recursively finds a cluster where every point is within epsilon of a core point
or is a related core point. Core points must have at least minSamples neighbors
within epsilon distance

Returns -1 if not a core point
Returns a list of keys corresponding to points, if it is a core cluster,
and recursively explores neighbors 
"""
def findCluster(cluster, points, pKey, epsilon, minSamples, visited, noise):
    p = points[pKey]
    #finds all the neighbors within epsilon distance of point p
    for key in points.keys():
        point = points[key]
        if key not in visited:
            distance = Euclidean(point, p)
            if distance <= epsilon:
                cluster.add(key)

    #if a core point
    if len(cluster) >= minSamples:
        #protects against set size change during iteration
        clusterCopy = cluster.copy()
        #for point in cluster:
        for key in clusterCopy:
            point = points[key]
            if key not in visited: #only check unvisited points
                visited.add(key)
                neighborCluster = findCluster(cluster, points, key, epsilon, minSamples, visited, noise)
                if neighborCluster != - 1: #if a core point, combine cluster & neighbor cluster
                    cluster = cluster.union(neighborCluster)
    
    #not a core point
    else :
        noise.append(p)
        return -1
    return cluster

"""
Converts an NpArray into a dictionary where the key is the index
"""
def npArrayToDict(X):
    #keys = ????
    points = {}
    for i in range(len(X)):
        points[i] = X[i]
    return points

"""
Creates a dataframe with each cluster and noise point as rows and the list of points
correspoinding to each as elements of that row

Creates a list of classes corresponding to each point, -1 corresponds to noise

Returns tuple with the dataframe and classes list
"""
def formatDBSCAN(clusters, noise, points):
    newClusters = {}
    clusterCount = 0

    #convert keys to points in clusters
    for cluster in clusters:
        newCluster = []
        if type(cluster) != int:
            for key in cluster:
                newCluster.append(points[key])
            newClusters["Cluster " + str(clusterCount)] = newCluster
        clusterCount += 1

    newClusters["Noise"] = noise

    #create dataframe
    df = pd.DataFrame(list(newClusters.items()), columns=['Cluster', 'Points'])
    df.rename(index={df.shape[0] - 1: 'Noise'}, inplace=True)

    #create list of classes corresponding to points
    classes = [-1] * len(points)
    for i in range(len(clusters)):
        if clusters[i] != -1:
            for point in clusters[i]:
                classes[point] = i
    
    return (df, classes)

"""
Finds different clusters of datapoints, classifying a set of data.
The number of clusters/classes are determined by the algorithm itself
Returns a dataframe of each cluster and their corresponding points, as well as noise points
"""
def dbscan(X, epsilon, minSamples):
    points = npArrayToDict(X)
    visited = set()
    clusters = []
    noise = []
    while len(visited) < len(X):
        #choose random point
        key = np.random.randint(0, len(points))
        if key not in visited:
            p = points[key]
            cluster = set()
            cluster = findCluster(cluster, points, key, epsilon, minSamples, visited, noise)
            clusters.append(cluster)
    df, classes = formatDBSCAN(clusters, noise, points)
    return (df, classes)

"""
Testing data
"""
# X, y = make_blobs(n_samples=25, centers=5, n_features=2, random_state=100)

# df, classes = dbscan(X, 5, 3)
# print("\n", df)
# print("\n", classes)
        



