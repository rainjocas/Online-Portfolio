"""
Author: Rain Jocas

Sources: https://www.ibm.com/topics/k-means-clustering
https://en.wikipedia.org/wiki/K-means_clustering
https://www.inference.org.uk/mackay/itprnn/ps/284.292.pdf

"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
from sklearn.datasets import fetch_california_housing
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_blobs

"""
Find Euclidean distance between two points
"""
def Euclidean(point1, point2):
    x1, y1 = point1
    x2, y2 = point2
    xSquared = ((x1 - x2)**2)
    ySquared = ((y1 - y2)**2)
    return np.sqrt(xSquared + ySquared)

"""
Finds centroid closest to each point, and assigns points to the cluster of that centroid
"""
def assignCluster(dataPts, clusters):
    for point in dataPts:
        minD = float('inf')
        bestMeanIndex = 0 
        for i in range(len(clusters)):
            cluster = clusters[i]
            centroid, cList = cluster
            distance = Euclidean(centroid, point)
            if distance < minD:
                minD = distance
                bestMeanIndex = i
        bestCluster = clusters[bestMeanIndex]
        centroid, cList = bestCluster
        cList.append(point)
        cList = np.array (cList)

"""
Clears the data in each cluster
"""
def clearClusters(clusters):
    for i in range(len(clusters)):
        centroid, cList = clusters[i]
        cluster = (centroid, [])
        clusters[i] = cluster

"""
Calculates where each centroid should be according to its corresponding cluster
"""
def calculateCentroids(clusters):
    for i in range(len(clusters)):
        centroid, cList = clusters[i]
        clusterSize = len(cList)
        totalX = 0
        totalY = 0
        for point in cList:
            x, y = point
            totalX += x
            totalY += y
        if clusterSize > 0:
            newCentroid = np.array([totalX/clusterSize, totalY/clusterSize])
            newCluster = (newCentroid, cList)
            clusters[i] = newCluster
    return clusters

"""
Plots a graph of the data and current centroid positions
"""
def plotCentroids(dataPts, clusters):
    plt.scatter(dataPts[:,0],dataPts[:,1])
    for i in range(len(clusters)):
        centroid, cList = clusters[i]
        plt.scatter(centroid[0], centroid[1], marker = '*', c = 'black')
    plt.show()

"""
Creates a dataframe with each cluster as rows and the list of points correspoinding to each
as elements of that row

Creates a list of classes corresponding to each point

Returns tuple with the dataframe and classes list
"""
def formatKMeans(clusters, X):
    classes = [-1] * len(X)
    clusterDict = dict()
    for i in range(len(clusters)):
        centroid, cList = clusters[i]
        #assign points list to dictionary class
        clusterDict[i] = cList
        #assign class to the index of each pointxs
        for point in cList:
            for p in range(len(X)):
                if np.array_equal(X[p], point):
                    classes[p] = i
    df = pd.DataFrame(list(clusterDict.items()), columns=['Class', 'Points'])
    return (df, classes)


"""
Finds k different clusters of datapoints, classifying a set of data.
Each cluster corresponds to a class
Returns a dataframe of each class and their corresponding points
"""
def kMeans(X, k):
    if k == 0:
        return "Must output a"
    plt.scatter(X[:,0], X[:,1])
    clusters = []
    #make list of random centroids
    for i in range(k):
        centroid = 2 * (2 * np.random.random((X.shape[1],)) - 1)
        cluster = (centroid, [])
        clusters.append(cluster)
    #plotCentroids(X, clusters)
    #iterate k times
    for i in range(k):
        assignCluster(X, clusters) #assign points to a cluster
        clusters = calculateCentroids(clusters) #update centroids
        clearClusters(clusters) #clear clusters lists
        # plotCentroids(X, clusters) #plot
    #return clusters (classification) on final iteration
    assignCluster(X, clusters)
    clusters = calculateCentroids(clusters)
    df, classes = formatKMeans(clusters, X)
    return (df, classes)

"""
The same as kMeans(), except it plots the centroid positions for every iteration
Ideally should only be used for small values of k
"""
def kMeansWithPlotting(X, k):
    plt.scatter(X[:,0], X[:,1])
    clusters = []
    #make list of random centroids
    for i in range(k):
        centroid = 2 * (2 * np.random.random((X.shape[1],)) - 1)
        cluster = (centroid, [])
        clusters.append(cluster)
    plotCentroids(X, clusters)
    #iterate k - 1 times (k times in total)
    for i in range(k - 1):
        assignCluster(X, clusters) #assign points to a cluster
        clusters = calculateCentroids(clusters) #update centroids
        clearClusters(clusters) #clear clusters lists
        plotCentroids(X, clusters) #plot
    #return clusters (classification) on final iteration
    assignCluster(X, clusters)
    clusters = calculateCentroids(clusters)
    df, classes = formatKMeans(clusters, X)
    return (df, classes)