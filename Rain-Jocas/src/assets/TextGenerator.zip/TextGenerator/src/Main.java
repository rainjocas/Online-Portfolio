public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}


// prompt the user to enter name of input file
//prompt for desired value of k

//do basic error checks on inputs
//if it doesn't work, print error code and exit

//print 500 characters of randomly generated text

//The first k characters of the output text should be the same as
// the first k characters of the input text – in other words,
// the first k input characters will be the starting sequence used
// to generate the first random character.

// Given a string of k = 2 characters and the following (third) character
// from the input text, update the count associated with the third character.

// This operation will be used when processing the input file and building
// the data structure containing characters and counts.

//Given a string of k = 2 characters, calculate the probability to
// select the next (i.e., third) character to follow.
//This operation will be used when generating the output text.

//your structure will be built around Map objects –
// the Java equivalent of dictionaries in Python.
// You will need to develop two primary classes,
// as well as a third that just contains your main method.