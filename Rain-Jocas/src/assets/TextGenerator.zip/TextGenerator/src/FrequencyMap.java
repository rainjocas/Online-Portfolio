import java.util.HashMap;
import java.util.ArrayList;


/**
 * Creates a Frequency Map object for a sequence where key is the char
 * following the sequence and value is the frequency of that char
 * following the sequence
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.12
 */
public class FrequencyMap {
    public HashMap<String, Integer> allFrequencies;
    private final String sequence;
    private final String words;


    /**
     * builds a FrequencyMap
     * @param text
     * @param seq
     */
    public FrequencyMap (String text, String seq){
        this.sequence = seq;
        this.words = text;
        this.allFrequencies = frequencies();
    }


    /** @return String words */
    public String getWords(){
        return words;
    }


    /** @return HashMap<String, Integer> allFrequencies */
    public HashMap<String, Integer> getFrequencies(){
        return allFrequencies;
    }


    /**
     * finds all occurences of sequence within words, and creates an Arraylist with each value being
     * String (sequence + next character)
     * i.e: [the, the, the, thi]
     * @return ArrayList<String> allOccurences
     */

    public ArrayList<String> findSequences(){
        ArrayList<String> allOccurences = new ArrayList<>(); // Create an ArrayList object
        for (int i = 0; i < words.length() - sequence.length(); i++){ //change to k
            String instance = words.substring(i, i + sequence.length()); //change to k
            String threeChars = words.substring(i, i + sequence.length() + 1); //change to k
            if (instance.equals(sequence)){
                allOccurences.add(threeChars);
            }
        }
        return allOccurences;
    }


    /**
     * iterate through all sequences
     * if the third character of the sequence ! in map, put new key with value 1
     * if third character in map, value += 1
     * @return HashMap sequenceMap
     */
    public HashMap<String, Integer> frequencies(){
        ArrayList<String> allSequences = findSequences(); //i.e. [the, the, the, thi]
        HashMap<String, Integer> sequenceMap = new HashMap<>(); //key: letter ('i' or 'e'), value: # of times
        // key shows up in arrayList allSequences
        for (String seq : allSequences){
            String letter = seq.substring(sequence.length());
            if (sequenceMap.containsKey(letter)){ // originally had if (allSequences.contains(seq)){
                int count = sequenceMap.get(letter); //had a problem here, solved it
                sequenceMap.replace(letter, count + 1);
            }
            else{
                sequenceMap.put(letter, 1);
            }
        }
        return sequenceMap;
    }


    /**
     * Creates a String representation of HashMap allFrequencies
     * @return String freqMapString
     */
    public String toString(){
        String freqMapString = "";
        System.out.println(this.allFrequencies.getClass());
        for (HashMap.Entry<String,Integer> letter :allFrequencies.entrySet()){
            int value = letter.getValue();
            System.out.println(value);
            freqMapString += letter.getKey() +":"+ Integer.toString(letter.getValue());
        }
        System.out.println(freqMapString);
        return freqMapString;
    }
}

