import java.util.HashMap;
import java.util.Map;


/**
 * Creates a Sequence Table by repeatedly creating Frequency Maps
 * for the value, with each sequence as the associated key
 * i.e [th = [i=1, e=3]]
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.06
 */
public class SequenceTable {
    //instance variables
    private String text;
    private static HashMap<String, HashMap<String, Integer>> table;
    //this is a default k value, is subject to change courtesy of setK() method
    private static int k = 0;
    //private final int k;


    /**
     * Builds a SequenceTable
     * @param words a string representation of a file
     * @param kLength the length of each sequence
     */
    public SequenceTable(String words, int kLength) {
        this.text = words;
        //this.table = buildTable();
        this.k = kLength;
    }


    public void setK(int kLength) {
        this.k = kLength;
    }


    /**
     * scans through file in the form of a loop and checks if prefix is in the table
     * If no, create new FrequencyMap and add to the Sequence table
     * @return
     */
    public void buildTable() {
        HashMap<String, HashMap<String, Integer>> seqTable = new HashMap<>();
        for (int i = 0; i < text.length() - (k - 1); i++) {
            String seq = text.substring(i, i + k);
            if (!seqTable.containsKey(seq)) {
                FrequencyMap seqMap = new FrequencyMap(text, seq);
                HashMap<String, Integer> frequencies = seqMap.getFrequencies();
                seqTable.put(seq, frequencies);
            }
        }
        this.table = seqTable;
        //return seqTable;
    }


    /**
     * @return table in the form of a nested hashmap
     */
    public HashMap<String, HashMap<String, Integer>> getSequenceTable(){
        return table;
    }


    /**
     * @return seqTableString, a string representation of the SequenceMap
     */
    public String toString() {
        String seqTableString = "";
        for (Map.Entry<String, HashMap<String, Integer>> tableInstance : table.entrySet()) {
            String newKey = tableInstance.getKey();
            HashMap<String, Integer> newFreqValue = tableInstance.getValue();
            seqTableString += "[" + tableInstance.getKey() + newFreqValue;
            seqTableString += "], ";
        }
        return seqTableString;
    }
}
