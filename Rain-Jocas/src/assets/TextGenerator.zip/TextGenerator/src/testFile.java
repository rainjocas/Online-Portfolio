import java.util.ArrayList;
import java.util.HashMap;


/**
 * Tests methods from FrequencyMap.java and SequenceTable.java
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.06
 */
public class testFile {
    public static void main(String[] args){
        printFrequencyMap();
        printSequenceTable();
    }


    /**
     * Tests methods in FrequencyMap.java
     */
    public static void printFrequencyMap(){
        FrequencyMap testFrequencyMap = new FrequencyMap("the theater is their thing", "th");
        //test getWords()
        System.out.println("printing getWords()");
        System.out.println(testFrequencyMap.getWords() + "\n"); //printing words
        //test findSequences()
        ArrayList<String> testFindSequences = testFrequencyMap.findSequences();
        System.out.println("testing findSequences()");
        System.out.println(testFindSequences + "\n");
        //test frequencies()
        System.out.println("testing frequencies()");
        HashMap<String, Integer> testSequenceMap = testFrequencyMap.frequencies();
        System.out.println(testSequenceMap + "\n");
        //test toString()
        System.out.println("testing toString()");
        System.out.println(testSequenceMap.toString() + "\n");
    }


    /**
     * tests methods in SequenceTable.java
     */
    public static void printSequenceTable(){
        //TODO: Build a SequenceTable and print it
        String filename = " "; //add an actual filename (ask for office hours help)
        SequenceTable testSequenceTable = new SequenceTable(filename, 2);
        System.out.println(testSequenceTable.toString());
    }
}
