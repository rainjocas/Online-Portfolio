import java.util.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


/**
 * Creates a string based on probability. Probabilities are found
 * using a String representation of the input file
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.06
 */

public class WordGen {
    private static final Random rand = new Random();


    /**
     * reads the input text, builds a SequenceTable, and generates and prints
     * a randomly-generated string based on the probabilities of the input text
     * @param args
     */
    public static void main(String[] args){
        String filename = inputFilename();
        int k = inputK();
        String words = readFileAsString(filename);
        SequenceTable tableObject = new SequenceTable(words, k);
        // initializes k to work for multiple values
        tableObject.setK(k);
        tableObject.buildTable();
        HashMap<String, HashMap<String, Integer>> table = tableObject.getSequenceTable();

        String monkeyTheorem = words.substring(0, k);//separates the first k letters of words
        int count = k;
        while (count < 501){
            String sequence = monkeyTheorem.substring(monkeyTheorem.length() - k);
            HashMap<String, Integer> newFreqMap = table.get(sequence);
            if (newFreqMap != null){
                if (newFreqMap.size() == 1){
                    String[] keys = (String[]) newFreqMap.keySet().toArray(new String[0]);
                    monkeyTheorem += keys[0];
                }
                if (newFreqMap.size() > 1){
                    monkeyTheorem += probabilities(newFreqMap);
                }
            }
            else {
                monkeyTheorem += randomChar();
            }
            count += 1;
        }
        System.out.println(monkeyTheorem);
    }


    /**
     * Given a filename, read the file and return its contents
     * as a String.
     * @param filename The name of the file to read.
     * @return The text of the file, or null if it could not be read.
     */
    private static String readFileAsString(String filename) {
        try {
            return Files.readString(Paths.get(filename));
        } catch (IOException e) {
            return null;
        }
    }


    /**
     * Generate a random letter from ‘a’ to ‘z’.
     * @return The random character.
     */
    private static char randomChar() {
        return (char) (rand.nextInt(26) + 'a');
    }


    /**
     * Helper method
     * selects a letter from frequency map based on its frequency of occurrence
     * @param freqMap
     * @return letter that has been selected based on probability
     */
    private static String probabilities(HashMap<String, Integer> freqMap ){
        String[] keys = (String[]) freqMap.keySet().toArray(new String[0]);
        int upperBound = 0;
        for (int i = 0; i < keys.length; i++){
            upperBound += freqMap.get(keys[i]);
        }
        int probability = rand.nextInt(upperBound);
        int counter = 0;
        for (String key: freqMap.keySet()) {
            counter += freqMap.get(key);
            if (counter >= probability) {
                return key; //stops here
            }
        }
        return null; //shouldn't ever actually get this far
    }


    /**
     * Helper method
     * uses scanner to ask user for input in order to find k
     * @return k
     */
    private static int inputK(){
        Scanner s = new Scanner(System.in);
        System.out.println("What is k?");
        int k = Integer.parseInt(s.nextLine());
        return k;
    }


    /**
     * Helper method
     * uses scanner to ask user for input in order to find filename
     * @return filename (string)
     */
    private static String inputFilename(){
        Scanner s = new Scanner(System.in);
        System.out.println("What is the filename");
        String filename = s.nextLine();
        return filename;
    }
}
