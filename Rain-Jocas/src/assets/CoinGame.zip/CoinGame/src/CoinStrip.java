import java.util.Random;

/**
 * Builds a CoinStrip, checks validity of movements, and moves coins around on the board
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.08
 */
public class CoinStrip {
    /** number of coins in the game */
    private final int numCoins;
    /** creates a board for the game in the form of a int[] */
    private int[] board;
    /** constructs a new CoinStrip with param coins, using helper method buildBoard()
     * @param coins, the number of coins in the game
     */
    public  CoinStrip(int coins) {
        this.numCoins = coins;
        this.board = buildBoard();
    }

    /**
     * @return an int[] the same length as the number of coins, where each index
     * represents a coin and the value at each index is its position on the board.
     */
    public int[] buildBoard(){
        //board should be 6 times larger than the number of coins
        int[] coinArray = new int[numCoins];
        for (int i = 0; i < numCoins; i++){
            Random rand = new Random();
            int spaces = rand.nextInt(6);
            int currentPoint = spaces + 1;
            if (i == 0){
                coinArray[i] = currentPoint;
            }
            else {
                coinArray[i] = coinArray[i - 1] + currentPoint;
            }
        }
        return coinArray;
    }

    /**
     * @param coin an integer representation of a coin
     * @param movement the number of spaces to the left a coin will move
     * creates a new board (as a String[])
     */
    public void moveCoin(int coin, int movement){
        int[] newBoard = board;
        if (checkLegality(coin, movement)){
            int position = board[coin];
            newBoard[coin] = position - movement;
        }
        this.board = newBoard;
    }

    /**
     * @param coin an integer representation of a coin
     * @param movement the number of spaces to the left a coin wants to move
     * @return whether both the coin and movement are valid in the game.
     */
    public boolean checkLegality(int coin, int movement){
        if (validCoin(coin)) {
            if (validMovement(coin, movement)){
                return true;
            }
        }
        return false;
    }

    /**
     * @param coin an integer representation of a coin
     * @return boolean of whether the coin exists in the game.
     */
    public boolean validCoin(int coin){
        if (coin > -1){
            if (coin < numCoins){
                return true;
            }
        }
        //System.out.println("Coin does not exist! Try again.");
        return false;
    }

    /**
     * @param coin an integer representation of a coin
     * @param movement he number of spaces to the left a coin wants to move
     * @ return boolean, true if legal and false if not
     * Movement is legal if there's enough spaces left on the board for that amount of movement,
     * and the movement would not require jumping over other coins.
     */
    public boolean validMovement(int coin, int movement){
        //checking if there's enough spaces left on the board
        if (board[coin] - movement < 0){
            //System.out.println("not enough space on the board");
            return false;
        }
        //0 can't move further
        if (coin == 0){
            if ((board[coin] - movement) < 0){
                return false;
            }
        }
        if (coin != 0){
            if ((board[coin] - movement) <= board[coin - 1]) {
                //System.out.println("Illegal movement! Try again.");
                return false;
            }
        }
        return true;
    }

    /**
     * @return true if game is over, false if not
     */
    public boolean isGameOver(){
        //int finalCoin = numCoins -1;
        //return board[finalCoin] == finalCoin;
        for (int i = 0; i < board.length; i++){
            if (i != board[i]){
                return false;
            }
        }
        return true;
    }

    /**
     * @return string that represents the board
     * (method can be used in a print statement in playGame)
     */
    public String printBoard() {
        String boardString = "|";
        for (int x = 0; x < board[0]; x++) {
            boardString += " |";
        }
        boardString += "0|";
        for (int i = 1; i < numCoins; i++) {
            int last = board[i - 1];
            for (int spaces = 1; spaces < board[i] - last; spaces++) {
                boardString += " |";
            }
            boardString += Integer.toString(i) + "|";
        }
        return boardString;
    }
}
