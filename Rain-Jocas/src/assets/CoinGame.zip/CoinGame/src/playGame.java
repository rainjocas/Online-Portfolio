import java.util.Scanner;
/**
 * This Class plays a game using user input and methods from the CoinStrip class
 * @author Rain Jocas + CS2101
 * @version 1.0 build 2023.02.08
 */
public class playGame {
    /**
     * Collects input from Player 1 and Player 2 (both user) and uses that input to move the position of coins
     * on the board, if the input is valid. Prints the board between each movement. Determines when the game is won
     * and then exists code
     */
    public static void main(String[] args) {
        CoinStrip game = new CoinStrip(3);
        System.out.println(game.printBoard());
        boolean playing = true;
        while (playing){
            int[] play1Moves = inputMove("Player 1");
            game.moveCoin(play1Moves[0], play1Moves[1]);
            System.out.println(game.printBoard());
            if (game.isGameOver()) {
                System.out.println("Player 1 wins!");
                playing = false;
                break;
                //System.out.println("isn't stopping after game over for some reason");
            }
            int[] play2Moves = inputMove("Player 2");
            game.moveCoin(play2Moves[0], play2Moves[1]);
            System.out.println(game.printBoard());
            if (game.isGameOver()) {
                System.out.println("Player 2 wins!");
                playing = false;
            }
        }
    }

    /** collects the move from the user from input in the form of a int array
     * @param player which player the movement will represent
     * @return int array where array[0] is the coin, and array[1] is the move itself
     */
    public static int[] inputMove(String player) {
        Scanner s = new Scanner(System.in);
        System.out.println(player + ": Enter your move: ");
        String moves = s.nextLine();
        String[] placeHolder = moves.split(" ");
        int[] directions = new int[2];
        directions[0] = Integer.parseInt(placeHolder[0]);
        directions[1] = Integer.parseInt(placeHolder[1]);
        return directions;
    }
}



